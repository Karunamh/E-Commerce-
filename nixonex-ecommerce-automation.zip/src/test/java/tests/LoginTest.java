package tests;

import org.testng.annotations.Test;

public class LoginTest {
    @Test
    public void loginTest() {
        System.out.println("Login test executed successfully.");
    }
}
